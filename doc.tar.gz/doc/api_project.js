define({
  "name": "Online Shop - Low price",
  "version": "0.1.0",
  "description": "Base URL - http://api.shop.com/v1",
  "title": "Online Shop - Low price",
  "url": "http://api.shop.com/v1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-09-16T14:23:18.962Z",
    "url": "https://apidocjs.com",
    "version": "0.29.0"
  }
});
